﻿namespace Bloggie.web.Models.ViewModals
{
    public class AddTagRequest
    {
        public string Name { get; set; }
        public string DisplayName { get; set; }
    }
}
