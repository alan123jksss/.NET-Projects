﻿namespace Bloggie.web.Models.Domain
{
    public class Tag
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string DisplayName { get; set; }
        public ICollection<BlogPost> BlogPosts { get; set; }

        //if green line appears , this should not be nullable. If we pass null value, it cause error. If you want to pass null 
        //value , you should add ? example public string? Name { get; set; }
    }
}
