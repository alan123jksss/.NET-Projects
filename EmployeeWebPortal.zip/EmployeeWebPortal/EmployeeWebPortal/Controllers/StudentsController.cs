﻿using EmployeeWebPortal.Data;
using EmployeeWebPortal.Models;
using EmployeeWebPortal.Models.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EmployeeWebPortal.Controllers
{
    public class StudentsController : Controller
    {
        private readonly ApplicationDbContext applicationDbContext;

        public StudentsController(ApplicationDbContext applicationDbContext)
        {
            this.applicationDbContext = applicationDbContext;
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(AddStudentViewModel addStudent)
        {
            var student = new Student
            {
                Name = addStudent.Name,
                Email = addStudent.Email,
                Phone = addStudent.Phone,
                Subscribed = addStudent.Subscribed

            };
            await applicationDbContext.Students.AddAsync(student);
            await applicationDbContext.SaveChangesAsync();
        
            return View();
        }

        public async Task<IActionResult> List()
        {
            var students = await applicationDbContext.Students.ToListAsync();
            return View(students);
        }
    }
}
